# 1. This is a python project for the game FIFA's football player data analysis and visualization.

## 1. start of the project. 2024-12-13 19:24
